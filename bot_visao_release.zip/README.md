
# Bot Visão — Landing Page

Landing page pronta para GitHub Pages. Substitua os endpoints em `scripts/main.js` por seus webhooks/URLs (Zapier, Google Apps Script, Mailchimp serverless).

Arquivos importantes:
- `index.html` — página principal
- `styles/style.css` — estilos
- `scripts/main.js` — lógica do formulário e integrações (preencha CONFIG)
- `assets/demo.mp4` — vídeo de demonstração
- `assets/bot-screenshot.png` — screenshot do bot (substitua se desejar)

Para publicar no GitHub Pages:
1. Crie repositório no GitHub.
2. Faça upload dos arquivos do diretório `bot_visao_release` para o repo.
3. Ative GitHub Pages (Settings → Pages) usando a branch `main` (root).

Contato para suporte: suporte@botvisao.com
