
// scripts/main.js
const CONFIG = {
  ZAPIER_WEBHOOK_URL: '',
  GAS_DEPLOY_URL: '',
  MAILCHIMP_ENDPOINT: '',
  SUPPORT_EMAIL: 'maickodamassena900@gmail.com'
};

function postToZapier(data){ if(!CONFIG.ZAPIER_WEBHOOK_URL) return Promise.reject('Zapier URL not set'); return fetch(CONFIG.ZAPIER_WEBHOOK_URL, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}); }
function postToGAS(data){ if(!CONFIG.GAS_DEPLOY_URL) return Promise.reject('GAS URL not set'); return fetch(CONFIG.GAS_DEPLOY_URL, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}); }
function postToMailchimpServer(data){ if(!CONFIG.MAILCHIMP_ENDPOINT) return Promise.reject('Mailchimp endpoint not set'); return fetch(CONFIG.MAILCHIMP_ENDPOINT, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}); }

const form = document.getElementById('leadForm');
const msg = document.getElementById('formMsg');
form.addEventListener('submit', async (e)=>{
  e.preventDefault();
  msg.textContent='Enviando...';
  const payload = { name: document.getElementById('name').value, email: document.getElementById('email').value, interest: document.getElementById('interest').value, date: new Date().toISOString() };
  try{ if(CONFIG.ZAPIER_WEBHOOK_URL){ const r = await postToZapier(payload); if(r.ok){ msg.textContent='Obrigado! Verifique seu e-mail para os próximos passos.'; form.reset(); return; } } }catch(err){ console.warn('Zapier fail', err); }
  try{ if(CONFIG.GAS_DEPLOY_URL){ const r = await postToGAS(payload); if(r.ok){ msg.textContent='Obrigado! Registro salvo no Google Sheets.'; form.reset(); return; } } }catch(err){ console.warn('GAS fail', err); }
  try{ if(CONFIG.MAILCHIMP_ENDPOINT){ const r = await postToMailchimpServer(payload); if(r.ok){ msg.textContent='Obrigado! Inscrição confirmada.'; form.reset(); return; } } }catch(err){ console.warn('Mailchimp fail', err); }
  msg.innerHTML = 'Ocorreu um erro ao enviar automaticamente. <a href="mailto:maickodamassena900@gmail.com?subject=Interesse%20Bot%20Visao&body=Nome:%20'+encodeURIComponent(document.getElementById('name').value)+'%0AEmail:%20'+encodeURIComponent(document.getElementById('email').value)+'%0APlano:%20'+encodeURIComponent(document.getElementById('interest').value)+'">Clique aqui para enviar manualmente</a>.';
});

document.getElementById('cta-top').addEventListener('click', ()=>{ document.getElementById('name').focus(); document.getElementById('name').scrollIntoView({behavior:'smooth'}); });
document.getElementById('btn-demo').addEventListener('click', ()=>{ const v = document.getElementById('demoVideo'); if(v){ v.play(); v.scrollIntoView({behavior:'smooth'}); } });
document.getElementById('download-btn').addEventListener('click', (e)=>{ /* placeholder: later replace link or set href */ });
